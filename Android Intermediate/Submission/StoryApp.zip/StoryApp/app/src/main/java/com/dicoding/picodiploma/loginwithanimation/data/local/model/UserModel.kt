package com.dicoding.picodiploma.loginwithanimation.data.local.model

class UserModel (
    val name: String,
    val userid: String,
    val token: String,
    val isLogin: Boolean
)